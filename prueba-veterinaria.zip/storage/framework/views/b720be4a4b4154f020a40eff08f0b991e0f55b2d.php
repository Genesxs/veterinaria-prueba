<div class="row">
    <div class="col-4">
        <label for="document_owner" class="control-label">Número de documento del
            dueño:</label>
        <input class="form-control" name="document_owner" <?php echo e($errors->has('document_owner') ? 'is-invald' : ''); ?>

            value="<?php echo e(old('document_owner', $meet->document_owner)); ?>" id="document_owner">
        <?php if($errors->has('document_owner')): ?>
            <small class="text-danger"><?php echo e($errors->first('document_owner')); ?></small>
        <?php endif; ?>
    </div>
    <div class="col-4">
        <label for="name" class="control-label">Nombres:</label>
        <input class="form-control" name="name" <?php echo e($errors->has('name') ? 'is-invald' : ''); ?>

            value="<?php echo e(old('name', $meet->name)); ?>" id="name">
        <?php if($errors->has('name')): ?>
            <small class="text-danger"><?php echo e($errors->first('name')); ?></small>
        <?php endif; ?>
    </div>
    <div class="col-4">
        <label for="last_name" class="control-label">Apellidos:</label>
        <input class="form-control" name="last_name" <?php echo e($errors->has('last_name') ? 'is-invald' : ''); ?>

            value="<?php echo e(old('last_name', $meet->last_name)); ?>" id="last_name">
        <?php if($errors->has('last_name')): ?>
            <small class="text-danger"><?php echo e($errors->first('last_name')); ?></small>
        <?php endif; ?>
    </div>
</div>
<div class="row mt-3">
    <div class="col-4">
        <label for="pet_name" class="control-label">Nombre mascota:</label>
        <input class="form-control" name="pet_name" <?php echo e($errors->has('pet_name') ? 'is-invald' : ''); ?>

            value="<?php echo e(old('pet_name', $meet->pet_name)); ?>" id="pet_name">
        <?php if($errors->has('pet_name')): ?>
            <small class="text-danger"><?php echo e($errors->first('pet_name')); ?></small>
        <?php endif; ?>
    </div>
    <div class="col-4">
        <label for="meet_date">Escoje la fecha de cita:</label>
        <input type="date" name="meet_date" id="meet_date" class="form-control"
            value="<?php echo e(old('meet_date', Carbon\Carbon::parse($meet->meet_date)->format('Y-m-d'))); ?>"
            <?php echo e($errors->has('meet_date') ? 'is-invald' : ''); ?> id="meet_date">
        <?php if($errors->has('meet_date')): ?>
            <small class="text-danger"><?php echo e($errors->first('meet_date')); ?></small>
        <?php endif; ?>
    </div>
    <div class="col-4">
        <label for="meet_time">Escoge la hora de la cita:</label>
        <input type="time" name="meet_time" class="form-control" <?php echo e($errors->has('meet_time') ? 'is-invald' : ''); ?>

            value="<?php echo e(old('meet_time', Carbon\Carbon::parse($meet->meet_time)->format('H:i'))); ?>" id="meet_time">
        <?php if($errors->has('meet_time')): ?>
            <small class="text-danger"><?php echo e($errors->first('meet_time')); ?></small>
        <?php endif; ?>
    </div>
</div>

<script type="text/javascript">
    let meets = <?php echo json_encode($meet); ?>


    console.log(meets);

    function inhabilitar() {
        var currentDate = moment().format('YYYY-MM-DD');
        var currentTime = moment().format('H:mm:ss');
        var createTime = meets.meet_time;

        console.log(createTime);

        var dateMeet = moment(meets.meet_date).format('YYYY-MM-DD');
        var timeMeet = moment(meets.meet_time).format('H:mm:ss');

        var diff = parseInt(timeMeet) - parseInt(currentTime);

        console.log(diff);

        if(createTime == undefined){
            console.log('esta creando cita')
        }else if (dateMeet > currentDate) {
            document.getElementById('document_owner').readOnly = true;
            document.getElementById('name').readOnly = true;
            document.getElementById('last_name').readOnly = true;
            document.getElementById('pet_name').readOnly = true;

            console.log('editando cita con fecha mayor a la actual')
        } else if (dateMeet == currentDate   && diff > 2) {
            document.getElementById('document_owner').readOnly = true;
            document.getElementById('name').readOnly = true;
            document.getElementById('last_name').readOnly = true;
            document.getElementById('pet_name').readOnly = true;

            console.log('puede editar')
        } else {

            document.getElementById('document_owner').readOnly = true;
            document.getElementById('name').readOnly = true;
            document.getElementById('last_name').readOnly = true;
            document.getElementById('pet_name').readOnly = true;
            document.getElementById('meet_date').setAttribute('max', currentDate);
            document.getElementById('meet_date').setAttribute('min', currentDate);
            document.getElementById('meet_time').readOnly = true;

            console.log('no puede editar')
        }

        

    }

    $(document).ready(function() {
        inhabilitar();
    });
</script>
<?php /**PATH C:\xampp\htdocs\veterinaria-prueba\resources\views/meet/fields.blade.php ENDPATH**/ ?>